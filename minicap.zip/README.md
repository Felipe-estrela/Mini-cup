# MiniCap

Editor de vídeo inspirado no CapCut, feito em Flutter.
